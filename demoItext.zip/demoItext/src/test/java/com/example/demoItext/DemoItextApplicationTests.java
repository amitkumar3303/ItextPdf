package com.example.demoItext;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DemoItextApplicationTests {

	@Test
	void contextLoads() {
	}

}
