package com.example.demoItext.controller;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlElement;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
//@XmlRootElement(name="Friend")
@XmlAccessorType(XmlAccessType.FIELD)
public class Friend {

	@XmlElement(name="FriendName")
	String friendName;
	@XmlElement(name="FriendPlace")
	String friendPlace;
	
	
	
	
	
}
