package com.example.demoItext;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class DemoItextApplication {

	public static void main(String[] args) {
		SpringApplication.run(DemoItextApplication.class, args);
	}

}
