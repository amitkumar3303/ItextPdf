package com.example.demoItext.controller;

import java.util.List;

import javax.xml.bind.annotation.XmlAccessType;
import javax.xml.bind.annotation.XmlAccessorType;
import javax.xml.bind.annotation.XmlRootElement;

import lombok.Data;

@Data
@XmlRootElement(name="Friends")
@XmlAccessorType(XmlAccessType.FIELD)
public class Friends {

	
	List<Friend> friend;
}
