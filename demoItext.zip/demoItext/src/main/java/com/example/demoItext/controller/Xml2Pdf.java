package com.example.demoItext.controller;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.io.StringWriter;
import java.net.URL;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.util.ArrayList;
import java.util.Base64;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;
import javax.xml.transform.Source;
import javax.xml.transform.Transformer;
import javax.xml.transform.TransformerConfigurationException;
import javax.xml.transform.TransformerException;
import javax.xml.transform.TransformerFactory;
import javax.xml.transform.stream.StreamResult;
import javax.xml.transform.stream.StreamSource;

import org.dom4j.DocumentException;
import org.springframework.core.io.ClassPathResource;
import org.xhtmlrenderer.pdf.ITextRenderer;

public class Xml2Pdf {
	public static void main_bckup(String[] args)
			throws IOException, DocumentException, TransformerException, TransformerConfigurationException,
			FileNotFoundException, com.itextpdf.text.DocumentException, JAXBException {

		// String xmlValueAsInput = getXmlValue();

		TransformerFactory tFactory = TransformerFactory.newInstance();
// specify the input xsl file location to apply the styles for the pdf
// output file
		Transformer transformer = tFactory.newTransformer(new StreamSource("C:\\Amit-learning\\javadomain.xsl"));

// specify the input xml file location

		transformer.transform(new StreamSource("C:\\Amit-learning\\javadomain.xml"),
				new StreamResult(new FileOutputStream("C:\\\\Amit-learning\\javadomain.html")));

// Specifying the location of the html file (xml converted to html)
		String File_To_Convert = "C:\\Amit-learning\\javadomain.html";
		String url = new File(File_To_Convert).toURI().toURL().toString();
		System.out.println("" + url);
// Specifying the location of the outpuf pdf file.
		String HTML_TO_PDF = "C:\\Amit-learning\\PdfFromXml.pdf";

		OutputStream os = new FileOutputStream(HTML_TO_PDF);
		// OutputStream os = new FileOutputStream(new
		// ClassPathResource("src\\main\\resources\\PdfFromXml.pdf").toString());
		// OutputStream os = new FileOutputStream(HTML_TO_PDF);
		ITextRenderer renderer = new ITextRenderer();

		renderer.setDocument(url);
		renderer.layout();
		renderer.createPDF(os);

		// new start
		File fileInputpdf = new File("class path resource [PdfFromXml.pdf]");

		byte[] inputFile = Files.readAllBytes(Paths.get(fileInputpdf.getAbsolutePath()));
		byte[] encodedBytes = Base64.getEncoder().encode(inputFile);
		String encodedString = new String(encodedBytes);
		// new end

		os.close();
	}

	public static void main(String[] args)
			throws IOException, DocumentException, TransformerException, TransformerConfigurationException,
			FileNotFoundException, com.itextpdf.text.DocumentException, JAXBException {

		String xmlValueAsInput = getXmlValue();

//String to xml file start
		java.io.FileWriter fw = new java.io.FileWriter("javadomain.xml");
		fw.write(xmlValueAsInput);
		fw.close();
//String to xml file end

		TransformerFactory tFactory = TransformerFactory.newInstance();
		Transformer transformer = tFactory
				.newTransformer(new StreamSource(new ClassPathResource("javadomain.xsl").getPath()));
		transformer.transform(new StreamSource(new ClassPathResource("javadomain.xml").getPath()),
				// transformer.transform(new StreamSource(xmlValueAsInput),
				new StreamResult(new FileOutputStream(new ClassPathResource("javadomain.html").toString())));

		String File_To_Convert = new ClassPathResource("javadomain.html").toString();
		String url = new File(File_To_Convert).toURI().toURL().toString();
		System.out.println("" + url);

		OutputStream os = new FileOutputStream(new ClassPathResource("PdfFromXml.pdf").toString());

		ITextRenderer renderer = new ITextRenderer();

		renderer.setDocument(url);
		renderer.layout();
		renderer.createPDF(os);

//new start
		File fileInputpdf = new File("class path resource [PdfFromXml.pdf]");

		byte[] inputFile = Files.readAllBytes(Paths.get(fileInputpdf.getAbsolutePath()));
		byte[] encodedBytes = Base64.getEncoder().encode(inputFile);
		String encodedString = new String(encodedBytes);
		System.out.println("Encoded String "+encodedString);
//new end

		os.close();
	}

	public static String getXmlValue() {

		String xmlString = "";
		XMLtoPDF xmltoPDF = new XMLtoPDF();

		Friend friend = new Friend();
		friend.setFriendName("Hemakumar");
		friend.setFriendPlace("Arcot");

		xmltoPDF.setFriend(friend);

		try {
			JAXBContext context = JAXBContext.newInstance(XMLtoPDF.class);
			Marshaller jaxbMarshaller = context.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(xmltoPDF, sw);
			xmlString = sw.toString();

			System.out.println(xmlString);
		} catch (JAXBException e) {

			e.printStackTrace();
		}
		return xmlString;
	}
}