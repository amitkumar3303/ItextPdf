package com.example.demoItext.controller;

import java.io.StringWriter;
import java.util.ArrayList;
import java.util.List;

import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.PropertyException;

public class ObjectToXml {
	public static void main(String[] args) throws JAXBException {
		
		XMLtoPDF xmltoPDF=new XMLtoPDF();
		
		Friend friend = new Friend();
		friend.setFriendName("Hemakumar");
		friend.setFriendPlace("Arcot");
		
		xmltoPDF.setFriend(friend);
		
		try {
			JAXBContext context = JAXBContext.newInstance(XMLtoPDF.class);
			Marshaller jaxbMarshaller = context.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(xmltoPDF, sw);
			String xmlString = sw.toString();
			
			System.out.println(xmlString);
		} catch (PropertyException e) {
		
			e.printStackTrace();
		} 

	}
	public static void main_bck2(String[] args) throws JAXBException {
	
		Friend friend = new Friend();

		friend.setFriendName("Hemakumar");
		friend.setFriendPlace("Arcot");
		
		try {
			JAXBContext context = JAXBContext.newInstance(Friend.class);
			Marshaller jaxbMarshaller = context.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(friend, sw);
			String xmlString = sw.toString();
			
			System.out.println(xmlString);
		} catch (PropertyException e) {
		
			e.printStackTrace();
		} 

	}
	public static void main_backup(String[] args) throws JAXBException {

		Friends friends = new Friends();
		List<Friend> friendList = new ArrayList<>();
		Friend friend = new Friend();

		friend.setFriendName("Hemakumar");
		friend.setFriendPlace("Arcot");
		friendList.add(friend);
		
		friend = new Friend();
		friend.setFriendName("Chudar");
		friend.setFriendPlace("Vellore");
		friendList.add(friend);
		
		friend = new Friend();
		friend.setFriendName("Selva kumar");
		friend.setFriendPlace("Arcot");
		friendList.add(friend);

		friends.setFriend(friendList);
		

		try {

			JAXBContext context = JAXBContext.newInstance(Friends.class);
			
			Marshaller jaxbMarshaller = context.createMarshaller();
			jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, Boolean.TRUE);
			StringWriter sw = new StringWriter();
			jaxbMarshaller.marshal(friends, sw);
			
			String xmlString = sw.toString();
			System.out.println(xmlString);
		} catch (PropertyException e) {
		
			e.printStackTrace();
		} 

	}
}
